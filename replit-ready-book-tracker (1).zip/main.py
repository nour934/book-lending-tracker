
from flask import Flask, render_template, request, redirect, url_for, flash, send_file
import json
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = "secret"

DATA_FILE = "data.json"

def load_books():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return []

def save_books(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

def calculate_late_fee(due_date_str, return_date_str):
    due_date = datetime.strptime(due_date_str, '%Y-%m-%d')
    return_date = datetime.strptime(return_date_str, '%Y-%m-%d')
    days_late = (return_date - due_date).days
    return max(0, days_late * 100)

@app.route("/")
def books():
    book_list = load_books()
    return render_template("books.html", books=book_list)

@app.route("/return/<int:index>", methods=["POST"])
def return_book(index):
    book_list = load_books()
    return_date = datetime.now().strftime('%Y-%m-%d')
    book_list[index]["return_date"] = return_date
    book_list[index]["late_fee"] = calculate_late_fee(book_list[index]["due_date"], return_date)
    book_list[index]["status"] = "Available"
    save_books(book_list)
    flash(f"Returned. Late fee: {book_list[index]['late_fee']}₺", "info")
    return redirect(url_for("books"))

@app.route("/download")
def download():
    return send_file(DATA_FILE, as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
